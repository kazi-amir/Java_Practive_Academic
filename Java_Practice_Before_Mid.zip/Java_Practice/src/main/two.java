package main;

interface two {
    public void myMethod2();
}
