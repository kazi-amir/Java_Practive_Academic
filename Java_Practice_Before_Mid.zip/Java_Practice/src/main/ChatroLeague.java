
package main;

public class ChatroLeague extends Student{
    String leagueId;
    ChatroLeague(){
        leagueId = "kutta";
    }
    void print(){
        System.out.print("ChatroLeague ");
        super.print();
    }
}
