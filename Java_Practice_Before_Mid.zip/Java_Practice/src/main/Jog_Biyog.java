package main;

/**
 *
 * @author amir
 */
public class Jog_Biyog {
    int res;
    public void add(int a, int b){
        res = a+b;
        System.out.println("a + b = "+res);
    }
    public void sub(int a, int b){
        res = a-b;
        System.out.println("a - b = "+res);
    }
    
}
