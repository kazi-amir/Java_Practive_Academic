//import java.util.*;
package main;

public class Person {
    String name;
    int age;
    String nid;
    
    //Constructor 
    Person(){
        this.name = "----";
        this.age = 100;
        this.nid = "123456789";
    }

}
