package main;

interface three extends first, two {
    public void myMethod3();
}
