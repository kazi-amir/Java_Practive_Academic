package main;

class TClass implements two {
    public void myMethod2(){
        System.out.println("First Interface");
    }
}
