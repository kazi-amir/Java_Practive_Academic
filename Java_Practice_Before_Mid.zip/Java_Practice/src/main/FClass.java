package main;

class FClass implements first {
    public void myMethod(){
        System.out.println("First Interface");
    }
}
