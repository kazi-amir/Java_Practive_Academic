package main;

class ThClass implements three {
    public void myMethod(){
        System.out.println("Third one Interface");
    }
    public void myMethod2(){
        System.out.println("Third two Interface");
    }
    public void myMethod3(){
        System.out.println("Third two Interface");
    }
}
