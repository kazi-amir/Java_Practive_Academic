package main;

public abstract class Vehicle {
    
    public abstract void printStatus();
    
}
