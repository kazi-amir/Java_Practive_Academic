package main;

interface first {
    public void myMethod();
}
